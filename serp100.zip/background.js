const DEFAULT_NUM = 100;

chrome.runtime.onInstalled.addListener(async () => {
  const { num } = await chrome.storage.sync.get("num");
  if (!num) {
    await chrome.storage.sync.set({ num: DEFAULT_NUM });
  }
});