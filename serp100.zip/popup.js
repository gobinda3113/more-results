const VALUES = [10, 20, 30, 40, 50, 60, 80, 100];

(async () => {
  const { num } = await chrome.storage.sync.get("num");
  const container = document.getElementById("options");

  for (const v of VALUES) {
    const label = document.createElement("label");
    const radio = document.createElement("input");
    radio.type = "radio";
    radio.name = "num";
    radio.value = v;
    if (v === num) radio.checked = true;
    radio.addEventListener("change", async () => {
      await chrome.storage.sync.set({ num: v });
    });
    label.appendChild(radio);
    label.appendChild(document.createTextNode(v + " results"));
    container.appendChild(label);
  }
})();
